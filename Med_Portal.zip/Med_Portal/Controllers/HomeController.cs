using MedicalPortal.Models;
using Microsoft.AspNetCore.Mvc;
using MedicalPortal.Services;
using MedicalPortal.Data;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Controllers;

public class HomeController : Controller
{
    private readonly MedicalPortalService _portal;
    private readonly PortalDbContext _db;
    public HomeController(MedicalPortalService portal, PortalDbContext db) { _portal = portal; _db = db; }
    public async Task<IActionResult> Index()
    {
        ViewBag.PatientCount = (await _portal.GetPatients()).Count;
        ViewBag.DoctorCount = (await _portal.GetDoctors()).Count;
        ViewBag.AppointmentCount = await _db.Appointments.CountAsync();
        return View();
    }
    public async Task<IActionResult> Patients() => View(await _portal.GetPatients());
    public async Task<IActionResult> Doctors() => View(await _portal.GetDoctors());
    public async Task<IActionResult> Appointments() => View(await _db.Appointments.Include(a=>a.Patient).Include(a=>a.Doctor).OrderBy(a=>a.AppointmentDate).ToListAsync());
    public IActionResult Book() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Book(int patientId, int doctorId, DateTime date, string time)
    {
        if (!TimeSpan.TryParse(time, out var ts)) { TempData["Message"] = "Неверное время."; return RedirectToAction(nameof(Book)); }
        var result = await _portal.BookAppointment(patientId, doctorId, date, ts);
        TempData["Message"] = result.message; return RedirectToAction(nameof(Appointments));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(int id)
    {
        TempData["Message"] = await _portal.CancelAppointment(id) ? "Запись отменена." : "Запись не найдена.";
        return RedirectToAction(nameof(Appointments));
    }
    public async Task<IActionResult> Search(string q)
    {
        ViewBag.Query = q;
        ViewBag.Result = string.IsNullOrWhiteSpace(q) ? null : await _portal.FindPatient(q);
        return View();
    }
    public async Task<IActionResult> Statistics() => View(await _portal.GetStatistics());
    public IActionResult AddPatient() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddPatient(Patient patient)
    {
        if (!ModelState.IsValid) return View(patient);
        if (string.IsNullOrWhiteSpace(patient.PhoneNumber)) { ModelState.AddModelError(nameof(patient.PhoneNumber), "Телефон обязателен"); return View(patient); }
        _db.Patients.Add(patient); await _db.SaveChangesAsync();
        TempData["Message"] = "Пациент добавлен."; return RedirectToAction(nameof(Patients));
    }
    public IActionResult AddDoctor() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddDoctor(Doctor doctor)
    {
        if (!ModelState.IsValid) return View(doctor);
        _db.Doctors.Add(doctor); await _db.SaveChangesAsync();
        TempData["Message"] = "Врач добавлен."; return RedirectToAction(nameof(Doctors));
    }
    public IActionResult AddTest() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddTest(MedicalTest test)
    {
        if (!await _db.Patients.AnyAsync(p => p.Id == test.PatientId)) { ModelState.AddModelError("", "Пациент не найден."); return View(test); }
        _db.MedicalTests.Add(test); await _db.SaveChangesAsync(); TempData["Message"] = "Анализ добавлен."; return RedirectToAction(nameof(Index));
    }
    public IActionResult AddPrescription() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> AddPrescription(Prescription prescription)
    {
        if (!await _db.Patients.AnyAsync(p => p.Id == prescription.PatientId) || !await _db.Doctors.AnyAsync(d => d.Id == prescription.DoctorId))
        { ModelState.AddModelError("", "Проверьте ID пациента и врача."); return View(prescription); }
        prescription.CreatePrescription(); _db.Prescriptions.Add(prescription); await _db.SaveChangesAsync();
        TempData["Message"] = "Назначение создано."; return RedirectToAction(nameof(Index));
    }
    public IActionResult Pay() => View();
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Pay(int patientId, decimal amount)
    {
        if (amount <= 0 || !await _db.Patients.AnyAsync(p => p.Id == patientId))
        { TempData["Message"] = "Укажите существующего пациента и сумму больше нуля."; return RedirectToAction(nameof(Pay)); }
        var payment = new Payment { PatientId = patientId, Amount = amount };
        payment.MakePayment(); _db.Payments.Add(payment); await _db.SaveChangesAsync();
        TempData["Message"] = "Оплата успешно проведена."; return RedirectToAction(nameof(Statistics));
    }
    public IActionResult Error() => View();
}
