using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Patient : Person
{
    public int PatientId { get => Id; set => Id = value; }
    [Required] public string PhoneNumber { get; set; } = "";
    [EmailAddress] public string Email { get; set; } = "";
    public string Address { get; set; } = "";
    public void UpdateProfile(string fullName, string phone, string email, string address)
    {
        FullName = fullName;
        if (string.IsNullOrWhiteSpace(phone)) throw new ArgumentException("Телефон обязателен");
        PhoneNumber = phone.Trim(); Email = email.Trim(); Address = address.Trim();
    }
    public new int GetAge() => base.GetAge();
    public override void DisplayInfo() => Console.WriteLine($"Пациент: {FullName}, возраст: {GetAge()}, тел.: {PhoneNumber}");
}
