using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class MedicalTest
{
    [Key]
    public int TestId { get; set; }
    public string TestName { get; set; } = "";
    public DateTime TestDate { get; set; } = DateTime.Today;
    public string Result { get; set; } = "Ожидается";
    public int PatientId { get; set; }
    public Patient? Patient { get; set; }
    public void AddResult(string result) => Result = result;
    public void UpdateResult(string result) => Result = result;
    public void DisplayResult() => Console.WriteLine($"{TestName} ({TestDate:d}): {Result}");
}
