using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class Doctor : Person, IPayable
{
    public int DoctorId { get => Id; set => Id = value; }
    [Required] public string Specialization { get; set; } = "";
    [Range(0, 80)] public int Experience { get; set; }
    public string CabinetNumber { get; set; } = "";
    [Range(0, 100000000)] public decimal Salary { get; set; }
    public override void DisplayInfo() => Console.WriteLine($"Врач: {FullName}, {Specialization}, стаж {Experience} лет, кабинет {CabinetNumber}");
    public void UpdateSpecialization(string specialization) =>
        Specialization = string.IsNullOrWhiteSpace(specialization) ? throw new ArgumentException("Специализация обязательна") : specialization.Trim();
    public decimal CalculateSalary() => Salary;
    public decimal CalculatePayment() => CalculateSalary();
}
