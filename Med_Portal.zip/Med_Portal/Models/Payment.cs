namespace MedicalPortal.Models;

public enum PaymentStatus { Pending, Paid, Refunded }

public class Payment
{
    public int PaymentId { get; set; }
    public int PatientId { get; set; }
    public Patient? Patient { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaymentDate { get; set; } = DateTime.Now;
    public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Pending;
    public bool MakePayment()
    {
        if (Amount <= 0) return false;
        PaymentStatus = PaymentStatus.Paid; PaymentDate = DateTime.Now; return true;
    }
    public bool RefundPayment()
    {
        if (PaymentStatus != PaymentStatus.Paid) return false;
        PaymentStatus = PaymentStatus.Refunded; return true;
    }
    public void DisplayPayment() => Console.WriteLine($"Оплата #{PaymentId}: {Amount:C} — {PaymentStatus}");
}
