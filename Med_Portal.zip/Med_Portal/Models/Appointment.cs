using System.ComponentModel.DataAnnotations.Schema;

namespace MedicalPortal.Models;

public enum AppointmentStatus { Scheduled, Confirmed, Completed, Cancelled }

public class Appointment
{
    public int AppointmentId { get; set; }
    public int PatientId { get; set; }
    public Patient? Patient { get; set; }
    public int DoctorId { get; set; }
    public Doctor? Doctor { get; set; }
    public DateTime AppointmentDate { get; set; }
    public TimeSpan AppointmentTime { get; set; }
    public AppointmentStatus Status { get; set; } = AppointmentStatus.Scheduled;
    [NotMapped] public DateTime StartsAt => AppointmentDate.Date.Add(AppointmentTime);
    public void CreateAppointment() => Status = AppointmentStatus.Scheduled;
    public void CancelAppointment() => Status = AppointmentStatus.Cancelled;
    public void ConfirmAppointment() => Status = AppointmentStatus.Confirmed;
    public void DisplayAppointment() => Console.WriteLine($"{StartsAt:g}: {Patient?.FullName} — {Doctor?.FullName} ({Status})");
}
