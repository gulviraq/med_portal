namespace MedicalPortal.Models;

public class MedicalRecord
{
    public int Id { get; set; }
    public int RecordId { get; set; }
    public int PatientId { get; set; }
    public Patient? Patient { get; set; }
    public string Diagnosis { get; set; } = "";
    public string MedicalHistory { get; set; } = "";
    public DateTime CreationDate { get; set; } = DateTime.Now;
    public void AddDiagnosis(string diagnosis) => Diagnosis = diagnosis;
    public void UpdateHistory(string history) => MedicalHistory = history;
    public void DisplayRecord() => Console.WriteLine($"{Patient?.FullName}: {Diagnosis}; {MedicalHistory}");
}
