namespace MedicalPortal.Models;

public abstract class Person
{
    public int Id { get; set; }
    private string _fullName = "";
    public string FullName
    {
        get => _fullName;
        set => _fullName = string.IsNullOrWhiteSpace(value) ? throw new ArgumentException("ФИО обязательно") : value.Trim();
    }
    public DateTime BirthDate { get; set; } = DateTime.Today;
    public abstract void DisplayInfo();
    public int GetAge()
    {
        var age = DateTime.Today.Year - BirthDate.Year;
        if (BirthDate.Date > DateTime.Today.AddYears(-age)) age--;
        return Math.Max(0, age);
    }
}
