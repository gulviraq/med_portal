namespace MedicalPortal.Models;

public class Prescription
{
    public int PrescriptionId { get; set; }
    public int PatientId { get; set; }
    public Patient? Patient { get; set; }
    public int DoctorId { get; set; }
    public Doctor? Doctor { get; set; }
    public string MedicationName { get; set; } = "";
    public string Dosage { get; set; } = "";
    public string Duration { get; set; } = "";
    public void CreatePrescription() { }
    public void UpdatePrescription(string medication, string dosage, string duration)
    { MedicationName = medication; Dosage = dosage; Duration = duration; }
    public void DisplayPrescription() => Console.WriteLine($"{MedicationName}: {Dosage}, {Duration}");
}
