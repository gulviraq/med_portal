namespace MedicalPortal.Models;

public class Department
{
    public int DepartmentId { get; set; }
    public string DepartmentName { get; set; } = "";
    public int Floor { get; set; }
    public string PhoneNumber { get; set; } = "";
    public string HeadDoctor { get; set; } = "";
    // Агрегация: врач хранится отдельно и может существовать без отделения.
    public List<Doctor> Doctors { get; set; } = new();
    public void AddDoctor(Doctor doctor) { if (!Doctors.Any(d => d.Id == doctor.Id)) Doctors.Add(doctor); }
    public void RemoveDoctor(int doctorId) => Doctors.RemoveAll(d => d.Id == doctorId);
    public void DisplayDoctors() { foreach (var doctor in Doctors) doctor.DisplayInfo(); }
}
