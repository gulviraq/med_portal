namespace MedicalPortal.Models;
public class PortalStatistics
{
    public int Patients { get; set; }
    public int Doctors { get; set; }
    public int Appointments { get; set; }
    public int Completed { get; set; }
    public decimal PaidTotal { get; set; }
}
