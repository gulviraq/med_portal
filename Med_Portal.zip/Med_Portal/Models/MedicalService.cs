using System.ComponentModel.DataAnnotations;

namespace MedicalPortal.Models;

public class MedicalService
{
    [Key]
    public int ServiceId { get; set; }

    [Required]
    public string ServiceName { get; set; } = "";

    public string Description { get; set; } = "";

    private decimal _price;

    [Range(0, 100000000)]
    public decimal Price
    {
        get => _price;
        set => _price = value < 0
            ? throw new ArgumentOutOfRangeException(nameof(value))
            : value;
    }

    public int Duration { get; set; }

    public decimal CalculatePrice() => Price;

    public void UpdatePrice(decimal price) => Price = price;

    public void DisplayService() =>
        Console.WriteLine($"{ServiceName}: {Price:C}, {Duration} мин.");
}