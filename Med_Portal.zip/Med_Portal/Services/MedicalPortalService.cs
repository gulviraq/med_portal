using MedicalPortal.Data;
using MedicalPortal.Models;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Services;

public class MedicalPortalService
{
    private readonly PortalDbContext _db;
    public MedicalPortalService(PortalDbContext db) => _db = db;

    public async Task<List<Patient>> GetPatients() => await _db.Patients.OrderBy(p => p.FullName).ToListAsync();
    public async Task<List<Doctor>> GetDoctors() => await _db.Doctors.OrderBy(d => d.FullName).ToListAsync();
    public async Task<Patient?> FindPatient(string query) => await _db.Patients.FirstOrDefaultAsync(p =>
        p.Id.ToString() == query || p.FullName.Contains(query) || p.PhoneNumber.Contains(query));
    public async Task<bool> IsDoctorAvailable(int doctorId, DateTime date, TimeSpan time)
    {
        return !await _db.Appointments.AnyAsync(a => a.DoctorId == doctorId &&
            a.AppointmentDate.Date == date.Date && a.AppointmentTime == time &&
            a.Status != AppointmentStatus.Cancelled);
    }
    public async Task<(bool ok, string message)> BookAppointment(int patientId, int doctorId, DateTime date, TimeSpan time)
    {
        if (!await _db.Patients.AnyAsync(p => p.Id == patientId)) return (false, "Пациент не найден.");
        if (!await _db.Doctors.AnyAsync(d => d.Id == doctorId)) return (false, "Врач не найден.");
        if (!await IsDoctorAvailable(doctorId, date, time)) return (false, "Врач уже занят на указанное время!");
        _db.Appointments.Add(new Appointment { PatientId = patientId, DoctorId = doctorId,
            AppointmentDate = date.Date, AppointmentTime = time, Status = AppointmentStatus.Scheduled });
        await _db.SaveChangesAsync(); return (true, "Запись успешно создана.");
    }
    public async Task<bool> CancelAppointment(int id)
    {
        var appointment = await _db.Appointments.FindAsync(id);
        if (appointment == null) return false;
        appointment.CancelAppointment(); await _db.SaveChangesAsync(); return true;
    }
    public async Task<PortalStatistics> GetStatistics() => new()
    {
        Patients = await _db.Patients.CountAsync(),
        Doctors = await _db.Doctors.CountAsync(),
        Appointments = await _db.Appointments.CountAsync(),
        Completed = await _db.Appointments.CountAsync(a => a.Status == AppointmentStatus.Completed),
        PaidTotal = await _db.Payments.Where(p => p.PaymentStatus == PaymentStatus.Paid).SumAsync(p => (decimal?)p.Amount) ?? 0m
    };
}
