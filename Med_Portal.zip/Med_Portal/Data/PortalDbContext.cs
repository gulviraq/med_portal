using MedicalPortal.Models;
using Microsoft.EntityFrameworkCore;

namespace MedicalPortal.Data;

public class PortalDbContext : DbContext
{
    public PortalDbContext(DbContextOptions<PortalDbContext> options) : base(options) { }
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<MedicalRecord> MedicalRecords => Set<MedicalRecord>();
    public DbSet<MedicalTest> MedicalTests => Set<MedicalTest>();
    public DbSet<MedicalService> MedicalServices => Set<MedicalService>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Prescription> Prescriptions => Set<Prescription>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Appointment>()
            .HasOne(a => a.Patient).WithMany().HasForeignKey(a => a.PatientId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Appointment>()
            .HasOne(a => a.Doctor).WithMany().HasForeignKey(a => a.DoctorId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<MedicalRecord>()
            .HasOne(r => r.Patient).WithMany().HasForeignKey(r => r.PatientId)
            .OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Payment>()
            .HasOne(p => p.Patient).WithMany().HasForeignKey(p => p.PatientId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<MedicalTest>()
            .HasOne(t => t.Patient).WithMany().HasForeignKey(t => t.PatientId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Prescription>()
            .HasOne(p => p.Patient).WithMany().HasForeignKey(p => p.PatientId)
            .OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Prescription>()
            .HasOne(p => p.Doctor).WithMany().HasForeignKey(p => p.DoctorId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
