using MedicalPortal.Models;

namespace MedicalPortal.Data;

public static class SeedData
{
    public static void Initialize(PortalDbContext db)
    {
        if (db.Patients.Any()) return;
        var patient = new Patient { FullName = "Иванов Иван Иванович", BirthDate = new DateTime(1995, 5, 12),
            PhoneNumber = "+7 700 000 00 01", Email = "patient@example.com", Address = "Астана" };
        var doctor = new Doctor { FullName = "Садыкова Алия Ерлановна", BirthDate = new DateTime(1982, 3, 10),
            Specialization = "Терапевт", Experience = 12, CabinetNumber = "204", Salary = 350000 };
        db.Patients.Add(patient); db.Doctors.Add(doctor);
        db.Departments.Add(new Department { DepartmentName = "Терапевтическое отделение", Floor = 2,
            PhoneNumber = "+7 7172 00 00 00", HeadDoctor = "Садыкова Алия Ерлановна" });
        db.MedicalServices.Add(new MedicalService { ServiceName = "Первичная консультация",
            Description = "Приём врача-терапевта", Price = 5000, Duration = 30 });
        db.SaveChanges();
    }
}
